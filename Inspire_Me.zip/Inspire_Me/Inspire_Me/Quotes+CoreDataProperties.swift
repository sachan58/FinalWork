//
//  Quotes+CoreDataProperties.swift
//  Inspire_Me
//
//  Created by MacBook Air on 20/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//
//

import Foundation
import CoreData


extension Quotes {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Quotes> {
        return NSFetchRequest<Quotes>(entityName: "Quotes")
    }

    @NSManaged public var imageURL: String?
    @NSManaged public var quotesText: String?

}

//
//  UserConstants.swift
//  Inspire_Me
//
//  Created by MacBook Air on 20/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import Foundation

class UserConstants {
    
    static let quoteBaseURl = "http://apis.ameyapps.in/inspireme/v1/fetchQuotesCatWithId"
    static let chatBaseURL = "http://apis.ameyapps.in/inspireme/v1/fetchChatUsers"
    static let secureKey = "secure_key"
    static let typeId = "type_id"
    static let bodyKey1 = "Android"
    static let bodyKey2 = "iOS"
    static let httpMethod = "POST"
    static let quotes = "Quotes"
    static let conversations = "Conversations"
    static let doubleImageName = "double"
    static let quotesImageName = "quotes"
    static let earthImageName = "earth"
    static let chatEntity = "Chats"
    static let userName = "user_name"
    static let lastMessage = "last_message"
    static let userId = "user_id"
    static let messageTime = "last_date_time"
    static let userImageURL = "user_image"
    static let chatSortingKey = "messageTime"
    static let jsonQuoteKey = "quotesList"
    static let jsonChatKey = "userList"
    static let quotesText = "category_name"
    static let imageURL = "image_url"
    static let quoteSortingKey = "quotesText"
    
}

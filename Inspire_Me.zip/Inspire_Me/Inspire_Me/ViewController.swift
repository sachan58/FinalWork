//
//  ViewController.swift
//  Inspire_Me
//
//  Created by Priyanka Sachan on 05/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController  {

	@IBOutlet weak var pageControl: UIPageControl!
	@IBOutlet weak var collectionView: UICollectionView!
	@IBOutlet weak var scrollView: UIScrollView!
	
	@IBAction func pageChange(_ sender: Any) {
		let x = CGFloat(pageControl.currentPage) * scrollView.frame.size.width
		scrollView.setContentOffset(CGPoint(x: x, y: 0), animated: true)
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
        //Quotes.fetchedhResultController.delegate = self
        
        do {
            try Quotes.fetchedhResultController.performFetch()
            print("Count Fetched First: \(String(describing: Quotes.fetchedhResultController.sections?[0].numberOfObjects))")
        } catch let error  {
            print("ERROR: \(error)")
        }
        FetchResponseFromServer.getResponse { quotesData in
            Quotes.creatingChatEntityFrom(quotesData)
            self.collectionView.reloadData()
        }
		self.setupUI()
	}
	
	private func setupUI() {
		self.scrollView.delegate = self
		SetScrollViewContent.setSubview(self.scrollView)
		self.navigationItem.title = UserConstants.quotes
	}
}
extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {

	func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Quotes.fetchedhResultController.sections?.first?.numberOfObjects ?? 0
	}

	func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
		guard let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: UserConstants.quotes, for: indexPath) as? CollectionViewCell, let quotes = Quotes.fetchedhResultController.object(at: indexPath) as? Quotes else { return UICollectionViewCell() }
        DispatchQueue.main.async {
            cell.categoryNameLabel.text = quotes.quotesText
            cell.categoryImageView.loadImageUsingCacheWithURLString(quotes.imageURL ?? "")
        }
		return cell
	}

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let vc = ConversationTableViewController.instantiateViewControllerFromStoryboard() else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController: UIScrollViewDelegate {
	
	func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
		let pageNo = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        print(pageNo)
		pageControl.currentPage = Int(pageNo)
	}
}

extension ViewController: NSFetchedResultsControllerDelegate {
    
//    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
//        switch type {
//        case .insert:
//            if self.collectionView.window == nil {
//                return
//            }
//            self.collectionView.insertItems(at: [newIndexPath!])
//        case .delete:
//            self.collectionView.deleteItems(at: [indexPath!])
//        default:
//            break
//        }
//    }
}

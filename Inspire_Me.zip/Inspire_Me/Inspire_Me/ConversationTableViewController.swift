//
//  ConversationTableViewController.swift
//  Inspire_Me
//
//  Created by MacBook Air on 18/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import UIKit
import CoreData

class ConversationTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpUI()
    }
    
    private func setUpUI() {
        self.title = UserConstants.conversations
        Chats.fetchedhResultController.delegate = self
        
        do {
            try Chats.fetchedhResultController.performFetch()
            print("Count Fetched First: \(String(describing: Chats.fetchedhResultController.sections?[0].numberOfObjects))")
        } catch let error  {
            print("ERROR: \(error)")
        }
        FetchResponseFromServer.getConverstionsResponse { (conversations) in
            Chats.creatingChatEntityFrom(conversations)
            self.tableView.reloadData()
        }
    }
    
    class func instantiateViewControllerFromStoryboard() -> ConversationTableViewController? {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ConversationTableViewController") as? ConversationTableViewController
            return vc
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Chats.fetchedhResultController.sections?.first?.numberOfObjects ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: UserConstants.conversations, for: indexPath) as? TableViewCell, let chats = Chats.fetchedhResultController.object(at: indexPath) as? Chats else { return UITableViewCell() }
        cell.lastMessageLabel.text = chats.lastMessage
        cell.userNameLabel.text = chats.userName
        cell.dateTime.text = chats.messageTime
        cell.userImageView.loadImageUsingCacheWithURLString(chats.userImageURL ?? "")
        return cell
    }

}
extension ConversationTableViewController: NSFetchedResultsControllerDelegate {
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            self.tableView.insertRows(at: [newIndexPath!], with: .automatic)
        case .delete:
            self.tableView.deleteRows(at: [indexPath!], with: .automatic)
        default:
            break
        }
    }
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.endUpdates()
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.beginUpdates()
    }
}

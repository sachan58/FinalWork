//
//  File.swift
//  Inspire_Me
//
//  Created by Manoj Nimbalkar on 05/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import Foundation

class FetchResponseFromServer {
	
	class func getResponse(completionBlock: @escaping (([[String : Any]]) -> Void)) {
		
		let dataToPost: [String : Any] = [UserConstants.secureKey : UserConstants.bodyKey1,
										  UserConstants.typeId : 1]
		let dataToPostInJson = try? JSONSerialization.data(withJSONObject: dataToPost)
		let urlString = URL(string: UserConstants.quoteBaseURl)
		
		if let url = urlString {
			var request = URLRequest(url: url)
			request.httpMethod = UserConstants.httpMethod
			request.httpBody = dataToPostInJson
			let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
				if error != nil {
					print(error as Any)
				} else {
					if let reusableData = data {
						guard let parsedData = try? JSONSerialization.jsonObject(with: reusableData, options: []) as? [String : Any], let quotesData = parsedData?[UserConstants.jsonQuoteKey] as? [[String : Any]] else { return }
                        DispatchQueue.main.sync {
                            completionBlock(quotesData)
                        }
					}
				}
			}
			task.resume()
		}
	}
    
    class func getConverstionsResponse(completionBlock: @escaping (([[String : Any]]) -> Void)) {
        
        let dataToPost: [String : Any] = [UserConstants.secureKey : UserConstants.bodyKey2]
        let dataToPostInJson = try? JSONSerialization.data(withJSONObject: dataToPost)
        let urlString = URL(string: UserConstants.chatBaseURL)
        
        if let url = urlString {
            var request = URLRequest(url: url)
            request.httpMethod = UserConstants.httpMethod
            request.httpBody = dataToPostInJson
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                if error != nil {
                    print(error as Any)
                } else {
                    if let reusableData = data {
                        guard let parsedData = try? JSONSerialization.jsonObject(with: reusableData, options: []) as? [String : Any], let userData = parsedData?[UserConstants.jsonChatKey] as? [[String : Any]] else { return }
                        print(userData)
                        DispatchQueue.main.sync {
                            completionBlock(userData)
                        }
                    }
                }
            }
            task.resume()
        }
    }
}

//
//  ScrollViewData.swift
//  Inspire_Me
//
//  Created by Manoj Nimbalkar on 07/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import UIKit

class SetScrollViewContent {
	
	class func setSubview(_ scrollView: UIScrollView) {
		var imageArray = [UIImage(named: UserConstants.doubleImageName), UIImage(named: UserConstants.quotesImageName), UIImage(named: UserConstants.earthImageName)]
		for index in 0..<imageArray.count {
            let imageView = UIImageView(frame: CGRect(x: scrollView.frame.size.width * CGFloat(index), y: 0, width: scrollView.frame.size.width, height: scrollView.frame.size.height))
            imageView.contentMode = .scaleAspectFill
			imageView.image = imageArray[index]
			scrollView.addSubview(imageView)
		}
        scrollView.contentSize = CGSize(width: scrollView.frame.size.width * 3, height: scrollView.frame.size.height)
	}
}

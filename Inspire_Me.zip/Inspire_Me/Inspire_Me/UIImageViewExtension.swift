//
//  FetchImageFromUrl.swift
//  Inspire_Me
//
//  Created by Manoj Nimbalkar on 06/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//

import UIKit

extension UIImageView {
	func getImage(from url: String) {
		guard let url =  URL(string: url) else { return }
		let task = URLSession.shared.dataTask(with: url) { data, response, error in
			guard
				let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
				let data = data, error == nil,
				let image = UIImage(data: data) else {
					print("error")
					return
			}
			DispatchQueue.main.async {
				self.image = image
			}
		}
		task.resume()
	}
}

import UIKit
let imageCache = NSCache<NSString, UIImage>()
extension UIImageView {
    func loadImageUsingCacheWithURLString(_ URLString: String) {
        self.image = nil
        if let cachedImage = imageCache.object(forKey: NSString(string: URLString )) {
            self.image = cachedImage
            return
        }
        if let url = URL(string: URLString) {
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                if error != nil {
                    print("ERROR LOADING IMAGES FROM URL: \(String(describing: error))")
                }
                DispatchQueue.main.async {
                    if let data = data {
                        if let downloadedImage = UIImage(data: data) {
                            imageCache.setObject(downloadedImage, forKey: NSString(string: URLString))
                            self.image = downloadedImage
                        }
                    }
                }
            }).resume()
        }
    }
}

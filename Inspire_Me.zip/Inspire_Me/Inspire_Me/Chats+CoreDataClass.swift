//
//  Chats+CoreDataClass.swift
//  Inspire_Me
//
//  Created by MacBook Air on 18/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


public class Chats: NSManagedObject {
   
    static var fetchedhResultController: NSFetchedResultsController<NSFetchRequestResult> = {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return NSFetchedResultsController() }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: UserConstants.chatEntity)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: UserConstants.chatSortingKey, ascending: true)]
        let frc = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedContext, sectionNameKeyPath: nil, cacheName: nil)
        return frc
    }()
    
    class func creatingChatEntityFrom(_ chatData: [[String : Any]]) {
        self.clearData()
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        for dict in chatData {
            if let chats = NSEntityDescription.insertNewObject(forEntityName: UserConstants.chatEntity, into: managedContext) as? Chats {
                chats.userName = dict[UserConstants.userName] as? String
                chats.lastMessage = dict[UserConstants.lastMessage] as? String
                chats.userId = dict[UserConstants.userId] as? String
                chats.messageTime = dict[UserConstants.messageTime] as? String
                chats.userImageURL = dict[UserConstants.userImageURL] as? String
            }
        }
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    class func clearData() {
        do {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: UserConstants.chatEntity)
            do {
                let objects  = try managedContext.fetch(fetchRequest) as? [NSManagedObject]
                _ = objects.map{$0.map{managedContext.delete($0)}}
                try managedContext.save()
            } catch let error {
                print("ERROR DELETING : \(error)")
            }
        }
    }

}

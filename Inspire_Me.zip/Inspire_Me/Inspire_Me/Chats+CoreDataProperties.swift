//
//  Chats+CoreDataProperties.swift
//  Inspire_Me
//
//  Created by MacBook Air on 18/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//
//

import Foundation
import CoreData


extension Chats {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Chats> {
        return NSFetchRequest<Chats>(entityName: "Chats")
    }

    @NSManaged public var userName: String?
    @NSManaged public var lastMessage: String?
    @NSManaged public var userId: String?
    @NSManaged public var messageTime: String?
    @NSManaged public var userImageURL: String?

}

//
//  Quotes+CoreDataClass.swift
//  Inspire_Me
//
//  Created by MacBook Air on 20/12/18.
//  Copyright © 2018 Priyanka Sachan. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


public class Quotes: NSManagedObject {
    
    static var fetchedhResultController: NSFetchedResultsController<NSFetchRequestResult> = {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return NSFetchedResultsController() }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: UserConstants.quotes)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: UserConstants.quoteSortingKey, ascending: true)]
        let frc = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedContext, sectionNameKeyPath: nil, cacheName: nil)
        return frc
    }()
    
    class func creatingChatEntityFrom(_ quoteData: [[String : Any]]) {
        //self.clearData()
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        for dict in quoteData {
            guard let quotes = NSEntityDescription.insertNewObject(forEntityName: UserConstants.quotes, into: managedContext) as? Quotes else { return }
            quotes.quotesText = dict[UserConstants.quotesText] as? String
            quotes.imageURL = dict[UserConstants.imageURL] as? String
        }
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    class func clearData() {
        do {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: UserConstants.quotes)
            do {
                let objects  = try managedContext.fetch(fetchRequest) as? [NSManagedObject]
                    _ = objects.map{$0.map{managedContext.delete($0)}}
                      try managedContext.save()
            } catch let error {
                print("ERROR DELETING : \(error)")
            }
        }
    }
    
    class func getImageData(from url: String) -> Data {
        var imageData = Data()
        guard let url =  URL(string: url) else { return Data() }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let data = data, error == nil else {
                    print("error")
                    return
            }
            DispatchQueue.main.async {
              imageData = data
            }
        }
        task.resume()
        return imageData
    }
}
